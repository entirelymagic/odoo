{
    'name': 'Hospital Management Service',
    'author': 'Elvis',
    'website': 'www.elvismunteanu.sostenia.com',
    'summary': 'Odoo 16 Development for Sostenia',
    'version': "0.1",
    
    'data': [
        'security/ir.model.access.csv',
        'views/menu.xml',
        'views/patient.xml',
    ]
}